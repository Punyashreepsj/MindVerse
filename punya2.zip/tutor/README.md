# Tutor Crew

Welcome to the Tutor Crew project, powered by [crewAI](https://crewai.com). This template is designed to help you set up a multi-agent AI system with ease, leveraging the powerful and flexible framework provided by crewAI. Our goal is to enable your agents to collaborate effectively on complex tasks, maximizing their collective intelligence and capabilities.

## Installation

Ensure you have Python >=3.10 <3.14 installed on your system. This project uses [UV](https://docs.astral.sh/uv/) for dependency management and package handling, offering a seamless setup and execution experience.

1.  **Install UV** (if you haven't already):
    ```bash
    pip install uv
    ```

2.  **Navigate to your project's root directory**:
    ```bash
    cd C:\Users\lekha\OneDrive\Desktop\Mini_Agents
    ```

3.  **Create and Activate a Virtual Environment** (using uv):
    ```bash
    uv venv
    # On Windows PowerShell:
    # .\.venv\Scripts\Activate.ps1
    # On macOS/Linux:
    # source .venv/bin/activate
    ```
    *Note: If you already have a `.venv` set up at the project root, you can skip `uv venv` and just activate it.* If you have multiple `.venv` directories, consider deleting the extra ones for a cleaner setup.

4.  **Install Project Dependencies**:
    ```bash
    uv pip install -e .
    ```
    This command installs all the dependencies listed in `pyproject.toml` into your virtual environment, including `crewai`, `fastapi`, and `uvicorn`.

5.  **Set up your `.env` file**:
    Create a file named `.env` in the root of your `tutor` directory (e.g., `C:\Users\lekha\OneDrive\Desktop\Mini_Agents\.env`) and add your OpenAI API key:
    ```
    OPENAI_API_KEY="your_openai_api_key_here"
    ```
    *Make sure to replace `"your_openai_api_key_here"` with your actual API key.*

### Customizing

**Add your `OPENAI_API_KEY` into the `.env` file**

- Modify `src/tutor/config/agents.yaml` to define your agents
- Modify `src/tutor/config/tasks.yaml` to define your tasks
- Modify `src/tutor/crew.py` to add your own logic, tools and specific args
- Modify `src/tutor/main.py` to add custom inputs for your agents and tasks

## Running the Project

To kickstart your FastAPI backend API, which serves the course tutor functionalities, navigate to your project's root directory (`C:\Users\lekha\OneDrive\Desktop\Mini_Agents`) and run the following command in your terminal:

```bash
uv run uvicorn tutor.src.tutor.api:app --reload --host 0.0.0.0 --port 8000
```

This command will start the FastAPI server, making your API endpoints accessible at `http://localhost:8000`. The `--reload` flag ensures that the server restarts automatically when you make changes to your code.


FRONTEND INTEGRATION:
### Frontend Integration Guide: Connecting React.js to the Course Tutor Backend API

This guide provides instructions for building a React.js frontend that interacts with the Course Tutor Backend API.

**Backend API Base URL:** `http://localhost:8000` (Assuming your FastAPI server is running on this address and port).

#### 1. Frontend Project Setup (React.js)

If you don't have a React project set up yet, you can create one using Vite (recommended for speed and simplicity) or Create React App.

**Using Vite (Recommended):**

1.  Open your terminal and navigate to the desired parent directory (e.g., `C:\Users\lekha\OneDrive\Desktop\Mini_Agents\frontend`).
2.  Run:
    ```bash
    npm create vite@latest frontend-tutor-app -- --template react
    cd frontend-tutor-app
    npm install
    npm run dev
    ```
    This will create a new React project, install dependencies, and start the development server (usually at `http://localhost:5173`).

**Using Create React App (Alternative):**

1.  Open your terminal and navigate to the desired parent directory.
2.  Run:
    ```bash
    npx create-react-app frontend-tutor-app
    cd frontend-tutor-app
    npm start
    ```
    This will create a new React project, install dependencies, and start the development server (usually at `http://localhost:3000`).

---

#### 2. Backend API Endpoints: Details for Frontend Consumption

Your React.js application will interact with the following API endpoints:

**A. `POST /generate-course` - Initiate Course Generation**

*   **Purpose**: Sends a user-provided topic to the backend to generate a new course and store its lessons in the database.
*   **Method**: `POST`
*   **URL**: `http://localhost:8000/generate-course`
*   **Request Body (JSON)**:
    ```json
    {
      "topic": "string" // e.g., "Programming in Python"
    }
    ```
*   **Expected Response (JSON)**:
    *   **Success (200 OK)**:
        ```json
        {
          "message": "Course generation initiated for topic: <your_topic_here>"
        }
        ```
    *   **Error (500 Internal Server Error)**:
        ```json
        {
          "detail": "An error occurred during course generation: <error_message>"
        }
        ```
*   **Frontend Usage**: This will be called when the user submits a topic (e.g., via an input field and a "Generate Course" button). It's an asynchronous operation; the backend agent will work in the background. The frontend should indicate that the generation is in progress.

---

**B. `GET /courses` - List All Available Course Topics**

*   **Purpose**: Retrieves a list of all course topics currently stored in the database.
*   **Method**: `GET`
*   **URL**: `http://localhost:8000/courses`
*   **Request Body**: None
*   **Expected Response (JSON Array)**:
    *   **Success (200 OK)**:
        ```json
        [
          { "topic": "Programming in Python" },
          { "topic": "Data Science Fundamentals" },
          // ... more course topics
        ]
        ```
    *   **Error (500 Internal Server Error)**:
        ```json
        {
          "detail": "An error occurred while fetching courses: <error_message>"
        }
        ```
*   **Frontend Usage**: Call this endpoint when the application loads or when a user wants to see available courses. Display these topics as selectable options (e.g., buttons, links, or a dropdown menu).

---

**C. `GET /courses/{topic}/lessons` - Retrieve Lessons for a Specific Course**

*   **Purpose**: Fetches all the lesson content for a given course topic. This is key for your "level-by-level" display.
*   **Method**: `GET`
*   **URL**: `http://localhost:8000/courses/<URL-ENCODED_TOPIC>/lessons`
    *   **Example**: For the topic "Web Development with React", the URL would be `http://localhost:8000/courses/Web%20Development%20with%20React/lessons`
*   **Request Body**: None
*   **Expected Response (JSON Array of Lesson Objects)**:
    *   **Success (200 OK)**:
        ```json
        [
          {
            "lesson_name": "Introduction to React",
            "lesson_content": {
              "introduction": "React is a JavaScript library...",
              "topic_1": "Components and Props",
              "topic_2": "State and Lifecycle",
              "topic_3": "Handling Events",
              "conclusion": "You've learned the basics of React."
            },
            "lesson_level": "Beginner"
          },
          {
            "lesson_name": "Advanced React Concepts",
            "lesson_content": {
              "introduction": "Building on basic React...",
              "topic_1": "Hooks (useState, useEffect)",
              "topic_2": "Context API",
              "topic_3": "Custom Hooks",
              "conclusion": "Mastered advanced React."
            },
            "lesson_level": "Intermediate"
          }
          // ... more lesson objects for the course
        ]
        ```
    *   **Error (404 Not Found)**:
        ```json
        {
          "detail": "No lessons found for topic: <your_topic_here>"
        }
        ```
    *   **Error (500 Internal Server Error)**:
        ```json
        {
          "detail": "An error occurred while fetching lessons for topic <your_topic_here>: <error_message>"
        }
        ```
*   **Frontend Usage**: Call this endpoint when the user selects a specific course topic. Store the returned array of lesson objects in your React component's state. Implement logic to display one lesson at a time ("level-by-level"). You'll use an index to track the current lesson being displayed. When the user completes a lesson, increment the index to show the next lesson. This is where you can insert your game logic between lessons.

### Understanding Your Crew

The tutor Crew is composed of multiple AI agents, each with unique roles, goals, and tools. These agents collaborate on a series of tasks, defined in `config/tasks.yaml`, leveraging their collective skills to achieve complex objectives. The `config/agents.yaml` file outlines the capabilities and configurations of each agent in your crew.

## Support

For support, questions, or feedback regarding the Tutor Crew or crewAI.
- Visit our [documentation](https://docs.crewai.com)
- Reach out to us through our [GitHub repository](https://github.com/joaomdmoura/crewai)
- [Join our Discord](https://discord.com/invite/X4JWnZnxPb)
- [Chat with our docs](https://chatg.pt/DWjSBZn)

Let's create wonders together with the power and simplicity of crewAI.





