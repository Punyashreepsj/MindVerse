import sqlite3
from crewai.tools.base_tool import BaseTool
#from crewai_tools import tool

class ReadDatabaseTool(BaseTool):
    name: str = "Read Database Tool"
    description: str = "Reads course content from the database based on a given topic."

    def _run(self, topic: str) -> str:
        lessons = get_lessons_by_topic(topic)
        if lessons:
            return str(lessons)
        else:
            return "No lessons found for the given topic."

def init_db():
    conn = sqlite3.connect('course_content.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS courses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            topic TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS lessons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            course_id INTEGER NOT NULL,
            lesson_name TEXT NOT NULL,
            lesson_level TEXT NOT NULL,
            introduction TEXT,
            topic_1 TEXT,
            topic_2 TEXT,
            topic_3 TEXT,
            conclusion TEXT,
            FOREIGN KEY (course_id) REFERENCES courses (id)
        )
    ''')
    conn.commit()
    conn.close()

def insert_course_data(topic: str, lessons: list):
    conn = sqlite3.connect('course_content.db')
    cursor = conn.cursor()

    # Check if course already exists
    cursor.execute('SELECT id FROM courses WHERE topic = ?', (topic,))
    result = cursor.fetchone()

    if result:
        course_id = result[0]
    else:
        cursor.execute('INSERT INTO courses (topic) VALUES (?)', (topic,))
        course_id = cursor.lastrowid

    for lesson in lessons:
        lesson_content = lesson['lesson_content']
        cursor.execute(
            'INSERT INTO lessons (course_id, lesson_name, lesson_level, introduction, topic_1, topic_2, topic_3, conclusion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            (
                course_id,
                lesson['lesson_name'],
                lesson['lesson_level'],
                lesson_content.get('introduction'),
                lesson_content.get('topic_1'),
                lesson_content.get('topic_2'),
                lesson_content.get('topic_3'),
                lesson_content.get('conclusion'),
            )
        )
    conn.commit()
    conn.close()

def get_all_courses_with_lessons():
    conn = sqlite3.connect('course_content.db')
    cursor = conn.cursor()

    cursor.execute('SELECT id, topic FROM courses')
    courses = cursor.fetchall()

    all_course_data = []
    for course_id, topic in courses:
        course_data = {'topic': topic, 'lessons': []}
        cursor.execute('''
            SELECT lesson_name, lesson_level, introduction, topic_1, topic_2, topic_3, conclusion
            FROM lessons
            WHERE course_id = ?
        ''',
        (course_id,))
        lessons = cursor.fetchall()
        for lesson_name, lesson_level, intro, t1, t2, t3, conc in lessons:
            lesson_content = {
                'introduction': intro,
                'topic_1': t1,
                'topic_2': t2,
                'topic_3': t3,
                'conclusion': conc,
            }
            course_data['lessons'].append({
                'lesson_name': lesson_name,
                'lesson_level': lesson_level,
                'lesson_content': lesson_content,
            })
        all_course_data.append(course_data)

    conn.close()
    return all_course_data

def get_all_course_topics():
    conn = sqlite3.connect('course_content.db')
    cursor = conn.cursor()
    cursor.execute('SELECT topic FROM courses')
    topics = [row[0] for row in cursor.fetchall()]
    conn.close()
    return topics

def get_lessons_by_topic(topic: str):
    conn = sqlite3.connect('course_content.db')
    cursor = conn.cursor()

    cursor.execute('SELECT id FROM courses WHERE topic = ?', (topic,))
    course_id = cursor.fetchone()

    if not course_id:
        conn.close()
        return []
    course_id = course_id[0]

    cursor.execute('''
        SELECT lesson_name, lesson_level, introduction, topic_1, topic_2, topic_3, conclusion
        FROM lessons
        WHERE course_id = ?
    ''',
    (course_id,))
    lessons_raw = cursor.fetchall()

    lessons_formatted = []
    for lesson_name, lesson_level, intro, t1, t2, t3, conc in lessons_raw:
        lesson_content = {
            'introduction': intro,
            'topic_1': t1,
            'topic_2': t2,
            'topic_3': t3,
            'conclusion': conc,
        }
        lessons_formatted.append({
            'lesson_name': lesson_name,
            'lesson_level': lesson_level,
            'lesson_content': lesson_content,
        })

    conn.close()
    return lessons_formatted
