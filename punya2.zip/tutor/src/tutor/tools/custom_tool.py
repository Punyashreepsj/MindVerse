from crewai.tools import BaseTool
from typing import Type
from pydantic import BaseModel, Field

import os
from tutor.src.tutor.tools.database import insert_course_data
import json

class WriteFileInput(BaseModel):
    """Input for WriteFileTool."""
    file_path: str = Field(..., description="Path to the file to write.")
    content: str = Field(..., description="Content to write to the file.")

class WriteFileTool(BaseTool):
    name: str = "Write File Tool"
    description: str = (
        "A tool that can write content to a specified file."
    )
    args_schema: Type[BaseModel] = WriteFileInput

    def _run(self, file_path: str, content: str) -> str:
        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with open(file_path, 'w') as f:
                f.write(content)
            return f"File successfully written to {file_path}"
        except Exception as e:
            return f"Error writing file {file_path}: {e}"

class WriteToDatabaseInput(BaseModel):
    """Input for WriteToDatabaseTool."""
    topic: str = Field(..., description="The topic of the course.")
    lesson: str = Field(..., description="The JSON string representation of a Lesson object.")

class WriteToDatabaseTool(BaseTool):
    name: str = "Write To Database Tool"
    description: str = (
        "A tool that can write a single lesson to the SQLite database."
    )
    args_schema: Type[BaseModel] = WriteToDatabaseInput

    def _run(self, topic: str, lesson: str) -> str:
        try:
            lesson_data = json.loads(lesson)
            insert_course_data(topic, [lesson_data])
            return f"Lesson for topic '{topic}' successfully added to database."
        except Exception as e:
            return f"Error adding lesson to database for topic '{topic}': {e}"
