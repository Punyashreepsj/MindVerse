import os
import sys
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
from fastapi.middleware.cors import CORSMiddleware
import traceback

# Adjust the path to import from the 'tutor' package
# sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from tutor.src.tutor.crew import Tutor
from tutor.src.tutor.tools.database import init_db, get_all_course_topics, get_lessons_by_topic

app = FastAPI()

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],  # Allow your React frontend origin
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request and response
class GenerateCourseRequest(BaseModel):
    topic: str

class CourseSummary(BaseModel):
    topic: str

class LessonContent(BaseModel):
    introduction: str
    topic_1: str
    topic_2: str
    topic_3: str
    conclusion: str

class Lesson(BaseModel):
    lesson_name: str
    lesson_content: LessonContent
    lesson_level: str

@app.on_event("startup")
async def startup_event():
    init_db()

@app.post("/generate-course")
async def generate_course(request: GenerateCourseRequest):
    """
    Endpoint to receive a topic from the frontend and trigger course generation.
    """
    try:
        inputs = {"topic": request.topic}
        # The crew itself will handle the database insertion via WriteToDatabaseTool
        Tutor().crew().kickoff(inputs=inputs)
        return {"message": f"Course generation initiated for topic: {request.topic}"}
    except Exception as e:
        traceback.print_exc()  # Print the full traceback to the console
        raise HTTPException(status_code=500, detail=f"An error occurred during course generation: {e}")

@app.get("/courses", response_model=List[CourseSummary])
async def get_courses():
    """
    Endpoint to retrieve a list of all available course topics.
    """
    try:
        topics = get_all_course_topics()
        return [{"topic": topic} for topic in topics]
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred while fetching courses: {e}")

@app.get("/courses/{topic}/lessons", response_model=List[Lesson])
async def get_course_lessons(topic: str):
    """
    Endpoint to retrieve all lessons for a specific course topic.
    """
    try:
        lessons = get_lessons_by_topic(topic)
        if not lessons:
            raise HTTPException(status_code=404, detail=f"No lessons found for topic: {topic}")
        return lessons
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred while fetching lessons for topic {topic}: {e}")
