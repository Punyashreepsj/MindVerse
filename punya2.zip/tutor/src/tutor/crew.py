from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai.agents.agent_builder.base_agent import BaseAgent
from crewai import LLM
from typing import List
from pydantic import BaseModel,Field
from tutor.src.tutor.tools.custom_tool import WriteToDatabaseTool
from dotenv import load_dotenv
import os
from tutor.src.tutor.tools.database import ReadDatabaseTool

load_dotenv()

class Lesson_Content(BaseModel):
    introduction:str
    topic_1:str
    topic_2:str
    topic_3:str
    conclusion:str

class Lesson(BaseModel):
    lesson_name:str
    lesson_content:Lesson_Content
    lesson_level:str


@CrewBase
class Tutor():
    """Tutor crew"""
    llm = LLM(model="gemini/gemini-2.5-flash")
    agents_config='config/agents.yaml'
    tasks_config='config/tasks.yaml'


    @agent
    def teacher(self) -> Agent:
        return Agent(
            config=self.agents_config['teacher'],
            llm=self.llm,
            verbose=True,
            tools=[WriteToDatabaseTool()]
        )


    @agent
    def game_generator(self) -> Agent:
        return Agent(
            config=self.agents_config['game_generator'],
            llm=self.llm,
            verbose=True,
            tools=[ReadDatabaseTool()]
        )


    @task
    def tutor_task(self) -> Task:
        return Task(
            config=self.tasks_config['tutor_task'],
            expected_output="A structured progression through three difficulty levels (Beginner, Intermediate, Advanced). Each lesson must have a detailed 'lesson_name', comprehensive 'lesson_content' with detailed explanations (at least 2-3 sentences) for each topic (topic_1, topic_2, topic_3), and a clear 'lesson_level' ('Beginner', 'Intermediate', or 'Advanced'). All lessons must be saved to the database immediately after generation using the Write To Database Tool."
            
        )

    @task
    def game_generation_task(self) -> Task:
        return Task(
            config=self.tasks_config['game_generation_task'],
            expected_output="A clear, organized, and structured game idea in JSON format based on the retrieved course content. The JSON should describe the game concept, genre, storyline, objectives, mechanics, and characters. The output must be suitable for direct saving to a database."
        )


    @crew
    def crew(self) -> Crew:
        """Creates the Tutor crew"""

        return Crew(
            agents=self.agents,
            tasks=self.tasks, 
            process=Process.sequential,
            verbose=True,
            
        )
