import React, { useState, useEffect } from "react";
import "./styles.css";

// Define interfaces for your data structure
interface LessonContent {
  introduction: string;
  topic_1: string;
  topic_2: string;
  topic_3: string;
  conclusion: string;
}

interface Lesson {
  lesson_name: string;
  lesson_content: LessonContent;
  lesson_level: string;
}

interface CourseSummary {
  topic: string;
}

export default function App() {
  const [topicInput, setTopicInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [allTopics, setAllTopics] = useState<CourseSummary[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<string>("");
  const [lessons, setLessons] = useState<Lesson[]>([]);
  // const [gameIdea, setGameIdea] = useState<GameIdea | null>(null);

  const API_BASE_URL = "http://localhost:8000";

  // Fetch all course topics on component mount and after a new course is generated
  const fetchAllTopics = async () => {
    setMessage(""); // Clear previous messages
    try {
      const response = await fetch(`${API_BASE_URL}/courses`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data: CourseSummary[] = await response.json();
      setAllTopics(data);
    } catch (error) {
      console.error("Error fetching topics:", error);
      setMessage("⚠️ Unable to fetch topics. Check backend server.");
    }
  };

  useEffect(() => {
    fetchAllTopics();
  }, []);

  // Fetch lessons and game idea when a topic is selected
  useEffect(() => {
    const fetchContentForSelectedTopic = async () => {
      if (selectedTopic) {
        setLoading(true);
        setMessage("");
        try {
          // Fetch lessons
          const lessonsResponse = await fetch(
            `${API_BASE_URL}/courses/${encodeURIComponent(selectedTopic)}/lessons`
          );
          if (!lessonsResponse.ok) {
            if (lessonsResponse.status === 404) {
              // No lessons found yet - might still be generating
              setLessons([]);
              setMessage("No lessons found for this topic yet. If you just generated the course, please wait a moment and click the topic again.");
              return;
            }
            throw new Error(`HTTP error! status: ${lessonsResponse.status}`);
          }
          const lessonsData: Lesson[] = await lessonsResponse.json();
          setLessons(lessonsData);
          if (lessonsData.length === 0) {
            setMessage("No lessons found for this topic yet. If you just generated the course, please wait a moment and click the topic again.");
          }

          // Assuming a new endpoint for fetching game idea by topic
          // If the game idea is stored with lessons, you might extract it from lessonsData
          // For now, let's assume an endpoint like /courses/{topic}/game-idea
          // You'll need to create this endpoint in api.py if it doesn't exist
          // const gameIdeaResponse = await fetch(
          //   `${API_BASE_URL}/courses/${selectedTopic}/game-idea`
          // );
          // if (!gameIdeaResponse.ok) {
          //   // Handle 404 specifically if no game idea exists yet
          //   if (gameIdeaResponse.status === 404) {
          //     setGameIdea(null);
          //   } else {
          //     throw new Error(`HTTP error! status: ${gameIdeaResponse.status}`);
          //   }
          // } else {
          //   const gameIdeaData: GameIdea = await gameIdeaResponse.json();
          //   setGameIdea(gameIdeaData);
          // }
        } catch (error) {
          console.error("Error fetching content for selected topic:", error);
          setMessage("⚠️ Error fetching content for this topic.");
          setLessons([]);
          // setGameIdea(null);
        } finally {
          setLoading(false);
        }
      } else {
        setLessons([]);
        // setGameIdea(null);
      }
    };

    fetchContentForSelectedTopic();
  }, [selectedTopic]);

  const handleGenerateCourseAndGame = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!topicInput.trim()) {
      setMessage("Please enter a topic!");
      return;
    }

    setLoading(true);
    setMessage("");

    try {
      const response = await fetch(`${API_BASE_URL}/generate-course`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: topicInput }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      const generatedTopic = topicInput.trim(); // Save the topic before clearing
      setMessage(data.message || "Course generation started! This may take a few minutes as content is generated level by level (Beginner → Intermediate → Advanced).");
      setTopicInput(""); // Clear input after submission
      await fetchAllTopics(); // Refresh topics list
      setSelectedTopic(generatedTopic); // Select the newly generated topic
    } catch (error) {
      console.error("Error generating course:", error);
      setMessage("⚠️ Unable to connect or generate course. Please check the server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-container">
      {/* Floating background lights */}
      <div className="orb orb1"></div>
      <div className="orb orb2"></div>
      <div className="orb orb3"></div>

      {/* Content */}
      <h1 className="title">📚 Agentic Tutor - Progressive Learning System</h1>
      <p className="subtitle">
        Enter a topic to generate a comprehensive course with detailed lessons organized by difficulty levels (Beginner → Intermediate → Advanced)
      </p>

      <form onSubmit={handleGenerateCourseAndGame}>
        <input
          type="text"
          placeholder="Enter your study topic (e.g., Photosynthesis)"
          value={topicInput}
          onChange={(e) => setTopicInput(e.target.value)}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Generating Course Content..." : "Generate Course 🚀"}
        </button>
      </form>

      {message && <p className="message">{message}</p>}

      <h2 className="section-title">Available Topics</h2>
      <div className="topics-list">
        {allTopics.length > 0 ? (
          allTopics.map((summary, index) => (
            <button
              key={index}
              className={`topic-button ${
                selectedTopic === summary.topic ? "selected" : ""
              }`}
              onClick={() => setSelectedTopic(summary.topic)}
              disabled={loading}
            >
              {summary.topic}
            </button>
          ))
        ) : (
          <p>No topics generated yet.</p>
        )}
      </div>

      {selectedTopic && (
        <div className="content-display">
          <h2 className="section-title">Content for: {selectedTopic}</h2>

          {lessons.length > 0 ? (
            <div className="lessons-container">
              {(() => {
                // Group lessons by level
                const lessonsByLevel = lessons.reduce((acc: { [key: string]: Lesson[] }, lesson) => {
                  (acc[lesson.lesson_level] = acc[lesson.lesson_level] || []).push(lesson);
                  return acc;
                }, {});
                
                // Define level order
                const levelOrder = ["Beginner", "Intermediate", "Advanced"];
                
                // Sort levels according to the defined order
                const sortedLevels = Object.entries(lessonsByLevel).sort(([levelA], [levelB]) => {
                  const indexA = levelOrder.indexOf(levelA);
                  const indexB = levelOrder.indexOf(levelB);
                  // If level not in order array, put it at the end
                  if (indexA === -1) return 1;
                  if (indexB === -1) return -1;
                  return indexA - indexB;
                });
                
                return sortedLevels.map(([level, lessonsInLevel]) => (
                  <div key={level} className="level-section">
                    <h3 className="level-heading">Level: {level}</h3>
                    {lessonsInLevel.map((lesson, index) => (
                      <div key={index} className="lesson-card">
                        <h4 className="lesson-title">{lesson.lesson_name}</h4>
                        
                        <div className="lesson-section">
                          <h5 className="section-label">Introduction</h5>
                          <p className="lesson-text">{lesson.lesson_content.introduction}</p>
                        </div>
                        
                        <div className="lesson-section">
                          <h5 className="section-label">Topic 1</h5>
                          <p className="lesson-text">{lesson.lesson_content.topic_1}</p>
                        </div>
                        
                        <div className="lesson-section">
                          <h5 className="section-label">Topic 2</h5>
                          <p className="lesson-text">{lesson.lesson_content.topic_2}</p>
                        </div>
                        
                        <div className="lesson-section">
                          <h5 className="section-label">Topic 3</h5>
                          <p className="lesson-text">{lesson.lesson_content.topic_3}</p>
                        </div>
                        
                        <div className="lesson-section">
                          <h5 className="section-label">Conclusion</h5>
                          <p className="lesson-text">{lesson.lesson_content.conclusion}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ));
              })()}
            </div>
          ) : (
            !loading && <p>No lessons found for this topic yet. Please wait for course generation to complete.</p>
          )}
        </div>
      )}
    </div>
  );
}
